import java.util.Scanner;

public class mainP {
	//Зад 2
	public static void main(String[] args) { 
	Scanner inp=new Scanner(System.in);
	int x=inp.nextInt();
	int y=inp.nextInt();
	int Uchenici=x*y;
	int DarvetaOtUcheniciVGrupa=(Uchenici/3)*7;
	int DarvetaOtOstanaliUchenici=Uchenici%3*2;
	System.out.println(DarvetaOtUcheniciVGrupa+DarvetaOtOstanaliUchenici);
	}
}

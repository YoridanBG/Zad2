import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
        Scanner inp=new Scanner(System.in);

        //Задача 1

        int k=inp.nextInt();
        int i;
        int sum=0;
        int count=0;
        for (i=0;i<k;i++){
            int num=inp.nextInt();    
                if (num<0){
                    sum+=num;
                    count++;
                }
            }
        int SA=sum/count;           
        System.out.println("Броят на средно аритметичното е "+SA);
        System.out.println("Броят на отрицателните числа е "+count);

        //Задача 2

        int n=inp.nextInt();
        int i;
        int sum=0;
        for (i=0;i<n;i++){
            int num=inp.nextInt();    
                if (num>0){
                    sum+=num;
                    count++;
                }
            }
        System.out.println("Сумата на числата е "+sum);
        System.out.println("Броят на положителните числа е "+count);

        //Задача 3 

        int multip=1;
        while (multip<200){
            int num=inp.nextInt();
            if(num>1){
            multip*=num;
            } 
        }
        System.out.println(multip);

        //Задача 4

        int sum=0;
        while (sum<80){
            int num=inp.nextInt();
            if (num>1){
                sum+=num;
            }
        }
        System.out.println(sum);

        //Задача 5

        int multip=3;
        while (multip<100){
            int num=inp.nextInt();
            if (num%3==0){
                multip*=num;
            }
        }
        System.out.println(multip);    
    
        //Задача 6

        int num = 1;
        int sum = 0;
        int count = 0;
        while (num!=0){
            num=inp.nextInt();
            if (num%2==0){
                sum+=num;
            } 
            else{          
                count++;
            }
        
        System.out.println("Сумата на числата е "+sum);
        System.out.println("Броят на положителните числа е "+count);}

        //Задача 7

        int n=inp.nextInt();
        int sum=0;            
        while (sum>=n){
            int num=inp.nextInt();
            if (num>0){
                sum+=num;
            }
        }
        System.out.println(sum);
    }
    
}       
